# Beyond Speed: Evaluating the Cognitive Cost of Accelerated Learning in Digital Education

Research repository containing dataset, analysis code, and visualizations for the paper.

Files:
- Research_Paper.pdf (upload your paper here)
- dataset.csv
- analysis.py
- visualization.py
- requirements.txt
