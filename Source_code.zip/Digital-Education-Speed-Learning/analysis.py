import pandas as pd

df = pd.read_csv("dataset.csv")

print("\nAverage scores by playback speed:")
print(df.groupby("PlaybackSpeed")[["RetentionScore","CognitiveLoad","Productivity"]].mean())

print("\nCorrelation matrix:")
print(df[["RetentionScore","CognitiveLoad","Productivity"]].corr())
