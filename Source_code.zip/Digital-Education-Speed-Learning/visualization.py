import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("dataset.csv")

ret = df.groupby("PlaybackSpeed")["RetentionScore"].mean()
load = df.groupby("PlaybackSpeed")["CognitiveLoad"].mean()

plt.figure(figsize=(6,4))
plt.bar(ret.index, ret.values)
plt.title("Retention Across Playback Speeds")
plt.savefig("figures/retention_chart.png")

plt.figure(figsize=(6,4))
plt.bar(load.index, load.values)
plt.title("Cognitive Load Across Playback Speeds")
plt.savefig("figures/cognitive_load_chart.png")
print("Charts saved in figures/")
